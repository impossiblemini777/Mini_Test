Original project name: Trip_Fact_Mini_Exercise2
Exported on: 01/05/2021 14:47:25
Exported by: WERNERDS\MKumari
Version: 1
Description: Testing in Attunity folder
